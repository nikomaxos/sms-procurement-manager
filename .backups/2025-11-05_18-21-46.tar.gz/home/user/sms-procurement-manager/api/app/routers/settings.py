from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from app.core.database import SessionLocal
from app.core.auth import get_current_user
import imaplib, json

router = APIRouter(tags=["Settings"])

def _get(k):
    with SessionLocal() as db:
        r = db.execute(text("SELECT v FROM app_settings WHERE k=:k"), {"k":k}).first()
        return r[0] if r else None

def _set(k, v):
    with SessionLocal() as db:
        db.execute(text("INSERT INTO app_settings(k,v) VALUES(:k,:v::jsonb) "
                        "ON CONFLICT (k) DO UPDATE SET v=:v::jsonb"),
                   {"k":k, "v":json.dumps(v)})
        db.commit()

@router.get("/settings/imap")
def get_imap(user: str = Depends(get_current_user)):
    return _get("imap") or {}

@router.put("/settings/imap")
def put_imap(body: dict, user: str = Depends(get_current_user)):
    _set("imap", body or {}); return {"ok":True}

@router.post("/settings/imap/test")
def test_imap(body: dict|None=None, user: str = Depends(get_current_user)):
    cfg = body or _get("imap") or {}
    host = cfg.get("host"); port=int(cfg.get("port") or (993 if cfg.get("ssl",True) else 143))
    username = cfg.get("user"); password = cfg.get("password"); use_ssl = bool(cfg.get("ssl",True))
    if not (host and username and password):
        raise HTTPException(400,"host/user/password required")
    try:
        M = imaplib.IMAP4_SSL(host, port) if use_ssl else imaplib.IMAP4(host, port)
        M.login(username, password)
        typ, data = M.list()
        M.logout()
        if typ != 'OK': raise HTTPException(400,"IMAP LIST failed")
        folders=[]
        for b in data or []:
            t = b.decode('utf-8', 'ignore')
            name = t.split(' "/" ',1)[-1].strip().strip('"')
            if name: folders.append(name)
        return {"ok":True, "folders":sorted(set(folders))}
    except imaplib.IMAP4.error as e:
        raise HTTPException(400, f"IMAP error: {e}")
    except Exception as e:
        raise HTTPException(400, f"IMAP connect error: {e}")

@router.get("/settings/system")
def get_system(user: str = Depends(get_current_user)):
    return _get("system") or {"note":"CORS=* (no credentials)"}

@router.put("/settings/system")
def put_system(body: dict, user: str = Depends(get_current_user)):
    _set("system", body or {}); return {"ok":True}
