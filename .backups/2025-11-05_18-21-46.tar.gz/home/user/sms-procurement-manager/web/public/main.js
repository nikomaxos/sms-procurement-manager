const $ = s=>document.querySelector(s);
const el = (t, attrs={}, ...kids)=>{ const x=document.createElement(t); for(const k in attrs){ if(attrs[k]!==null) x.setAttribute(k, attrs[k]); } kids.flat().forEach(k=>x.append(k.nodeType? k : document.createTextNode(k))); return x; };

let TOKEN = localStorage.getItem('TOKEN') || '';

async function authFetch(url, opt={}){
  opt.headers = Object.assign({'Content-Type':'application/json'}, opt.headers||{});
  if (TOKEN) opt.headers['Authorization'] = 'Bearer '+TOKEN;
  const resp = await fetch(url, opt);
  if (!resp.ok){
    const text = await resp.text().catch(()=> '');
    throw new Error(`${resp.status} ${text || resp.statusText}`);
  }
  const ct = resp.headers.get('content-type') || '';
  return ct.includes('application/json') ? resp.json() : resp.text();
}

function loginView(){
  const page = el('div',{class:'page'},
    el('div',{class:'card'},
      el('h2',{},'Login'),
      el('label',{},'API Base'), el('input',{id:'api',value:window.API_BASE,style:"width:100%"}),
      el('label',{},'Username'), el('input',{id:'u',value:'admin',style:"width:100%"}),
      el('label',{},'Password'), el('input',{id:'p',type:'password',value:'admin123',style:"width:100%"}),
      el('div',{style:"margin-top:8px;display:flex;gap:8px"},
        el('button',{class:'btn blue', id:'loginBtn'},'Login')
      )
    )
  );
  $('#app').innerHTML = ''; $('#app').append(page);
  $('#loginBtn').onclick = doLogin;
  $('#p').addEventListener('keydown', (e)=>{ if(e.key==='Enter') doLogin(); });
}

async function doLogin(){
  window.API_BASE = $('#api').value || window.API_BASE;
  localStorage.setItem('API_BASE', window.API_BASE);
  const form = new URLSearchParams();
  form.set('username', $('#u').value);
  form.set('password', $('#p').value);
  try{
    const data = await fetch(window.API_BASE+'/users/login',{method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:form});
    if(!data.ok){ alert('Login failed'); return; }
    const tok = await data.json();
    TOKEN = tok.access_token; localStorage.setItem('TOKEN', TOKEN);
    render(); // go home
  }catch(e){ alert(e.message); }
}

function ensureNav(){
  $('#btnTrends').onclick = viewTrends;
  $('#btnOffers').onclick = viewOffers;
  $('#btnSuppliers').onclick = viewSuppliers;
  $('#btnCountries').onclick = viewCountries;
  $('#btnNetworks').onclick = viewNetworks;
  $('#btnParsers').onclick = viewParsers;
  $('#btnSettings').onclick = viewSettings;
  $('#userbox').innerHTML = TOKEN ? 'User: admin ' : '';
  if (TOKEN){
    const lo = el('button',{class:'btn red',style:'margin-left:8px'},'Logout');
    lo.onclick = ()=>{ TOKEN=''; localStorage.removeItem('TOKEN'); render(); };
    $('#userbox').append(lo);
  }
}

async function viewTrends(){
  try{
    const today = new Date().toISOString().slice(0,10);
    const res = await authFetch(window.API_BASE+'/metrics/trends?d='+today);
    const card = el('div',{class:'card'}, el('h2',{},'Market trends (top networks)'),
      el('pre',{}, JSON.stringify(res.buckets, null, 2)));
    $('#app').innerHTML=''; $('#app').append(card);
  }catch(e){ alert('Trends error: '+e.message); }
}

async function listSimple(path){
  return authFetch(window.API_BASE+path);
}

async function viewOffers(){
  try{
    const data = await authFetch(window.API_BASE+'/offers/?limit=50&offset=0');
    const rows = data.rows || [];
    const table = el('table',{class:'table'},
      el('thead',{}, el('tr',{}, el('th',{},'ID'), el('th',{},'Supplier'), el('th',{},'Connection'), el('th',{},'Price'))),
      el('tbody',{}, rows.map(r=> el('tr',{}, el('td',{}, r.id), el('td',{}, r.supplier_name), el('td',{}, r.connection_name), el('td',{}, String(r.price)) )))
    );
    const card = el('div',{class:'card'}, el('h2',{},'Offers'), table);
    $('#app').innerHTML=''; $('#app').append(card);
  }catch(e){ alert('Offers error: '+e.message); }
}

async function viewSuppliers(){
  try{
    const rows = await listSimple('/suppliers/');
    const table = el('table',{class:'table'},
      el('thead',{}, el('tr',{}, el('th',{},'ID'), el('th',{},'Organization'))),
      el('tbody',{}, rows.map(r=> el('tr',{}, el('td',{}, r.id), el('td',{}, r.organization_name))))
    );
    const card = el('div',{class:'card'}, el('h2',{},'Suppliers'), table);
    $('#app').innerHTML=''; $('#app').append(card);
  }catch(e){ alert('Suppliers error: '+e.message); }
}

async function viewCountries(){
  try{
    const rows = await listSimple('/countries/');
    const table = el('table',{class:'table'},
      el('thead',{}, el('tr',{}, el('th',{},'ID'), el('th',{},'Name'), el('th',{},'MCC'), el('th',{},'MCC2'), el('th',{},'MCC3'))),
      el('tbody',{}, rows.map(r=> el('tr',{}, el('td',{}, r.id), el('td',{}, r.name), el('td',{}, r.mcc||''), el('td',{}, r.mcc2||''), el('td',{}, r.mcc3||''))))
    );
    const card = el('div',{class:'card'}, el('h2',{},'Countries'), table);
    $('#app').innerHTML=''; $('#app').append(card);
  }catch(e){ alert('Countries error: '+e.message); }
}

async function viewNetworks(){
  try{
    const rows = await listSimple('/networks/');
    const table = el('table',{class:'table'},
      el('thead',{}, el('tr',{}, el('th',{},'ID'), el('th',{},'Name'), el('th',{},'Country ID'), el('th',{},'MNC'), el('th',{},'MCC-MNC'))),
      el('tbody',{}, rows.map(r=> el('tr',{}, el('td',{}, r.id), el('td',{}, r.name), el('td',{}, r.country_id||''), el('td',{}, r.mnc||''), el('td',{}, r.mccmnc||''))))
    );
    const card = el('div',{class:'card'}, el('h2',{},'Networks'), table);
    $('#app').innerHTML=''; $('#app').append(card);
  }catch(e){ alert('Networks error: '+e.message); }
}

async function viewParsers(){
  try{
    const res = await listSimple('/parsers/');
    const card = el('div',{class:'card'}, el('h2',{},'Parsers (WYSIWYG planned)'), el('pre',{}, JSON.stringify(res,null,2)));
    $('#app').innerHTML=''; $('#app').append(card);
  }catch(e){ alert('Parsers error: '+e.message); }
}

async function viewSettings(){
  try{
    const enums = await authFetch(window.API_BASE+'/conf/enums');
    const state = JSON.parse(JSON.stringify(enums));
    const dirty = { route_type:false, known_hops:false, registration_required:false, any:false };

    function listBlock(key, label){
      const addInput = el('input',{placeholder:'Add new value', style:"width:200px"});
      const addBtn = el('button',{class:'btn green'},'Add');
      const saveBtn = el('button',{class:'btn blue'},`Save ${label}`);
      const ul = el('ul',{class:'pill-list'});

      function render(){
        ul.innerHTML = '';
        (state[key]||[]).forEach((v,i)=>{
          ul.append(el('li',{class:'pill-row'},
            el('span',{class:'pill'}, v),
            el('button',{class:'btn yellow'},'Edit'),
            el('button',{class:'btn red'},'Delete')
          ));
          ul.lastChild.children[1].onclick = ()=>{
            const nv = prompt('Edit value', v);
            if(nv && nv.trim() && nv!==v){ state[key][i]=nv.trim(); dirty[key]=dirty.any=true; render(); }
          };
          ul.lastChild.children[2].onclick = ()=>{
            state[key].splice(i,1); dirty[key]=dirty.any=true; render();
          };
        });
      }
      addBtn.onclick = ()=>{
        const nv = addInput.value.trim();
        if(nv){ state[key] = state[key]||[]; state[key].push(nv); addInput.value=''; dirty[key]=dirty.any=true; render(); }
      };
      saveBtn.onclick = async ()=>{
        try{
          const payload = {}; payload[key] = state[key];
          await authFetch(window.API_BASE+'/conf/enums', {method:'PUT', body: JSON.stringify(payload)});
          dirty[key]=false;
          alert(`${label} saved`);
        }catch(e){ alert(`Save ${label} failed: `+e.message); }
      };
      render();
      return el('div',{class:'card'},
        el('h3',{}, label),
        ul,
        el('div',{style:"display:flex;gap:8px"}, addInput, addBtn, saveBtn)
      );
    }

    const big = el('div',{class:'card'}, el('h2',{},'Drop Down Menus'));
    big.append(listBlock('route_type','Route type'));
    big.append(listBlock('known_hops','Known hops'));
    big.append(listBlock('registration_required','Registration required'));

    const saveAll = el('button',{class:'btn blue'},'Save All');
    saveAll.onclick = async ()=>{
      try{
        await authFetch(window.API_BASE+'/conf/enums', {method:'PUT', body: JSON.stringify(state)});
        alert('All dropdowns saved');
      }catch(e){ alert('Save All failed: '+e.message); }
    };

    const wrap = el('div',{class:'page'}, big, el('div',{}, saveAll));
    $('#app').innerHTML = ''; $('#app').append(wrap);
  }catch(e){ alert('Settings error: '+e.message); }
}

function render(){
  ensureNav();
  if (!TOKEN) return loginView();
  viewTrends();
}
document.addEventListener('DOMContentLoaded', render);
