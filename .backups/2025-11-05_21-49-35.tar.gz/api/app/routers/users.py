from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm
from app.core.auth import authenticate, create_token, get_current_user

router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/login")
def login(form: OAuth2PasswordRequestForm = Depends()):
    user = authenticate(form.username, form.password)
    if not user:
        return {"detail":"Unauthorized"}, 401
    return {"access_token": create_token(user), "token_type": "bearer"}

@router.get("/me")
def me(current = Depends(get_current_user)):
    return current
