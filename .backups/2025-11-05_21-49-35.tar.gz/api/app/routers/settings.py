from typing import Dict, Any
from fastapi import APIRouter, Depends, Body, HTTPException
from sqlalchemy import text
import json, imaplib, ssl
from app.core.database import engine
from app.core.auth import get_current_user

router = APIRouter(prefix="/settings", tags=["Settings"])

def _ensure_table():
    with engine.begin() as c:
        c.execute(text("""
        CREATE TABLE IF NOT EXISTS config_kv(
          key TEXT PRIMARY KEY,
          value JSONB NOT NULL,
          updated_at TIMESTAMPTZ DEFAULT now()
        );"""))

def _get(key:str, default:Dict[str,Any]):
    _ensure_table()
    with engine.begin() as c:
        row = c.execute(text("SELECT value FROM config_kv WHERE key=:k"), dict(k=key)).fetchone()
        if not row:
            c.execute(text("INSERT INTO config_kv(key,value) VALUES (:k,:v)"),
                      dict(k=key, v=json.dumps(default)))
            return default
        val = row.value
        if isinstance(val, str):
            try: val = json.loads(val)
            except Exception: val = default
        return {**default, **(val or {})}

def _set(key:str, value:Dict[str,Any]):
    with engine.begin() as c:
        c.execute(text("INSERT INTO config_kv(key,value,updated_at) VALUES(:k,:v,now()) "
                       "ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=now()"),
                  dict(k=key, v=json.dumps(value)))

DEFAULT_IMAP = {"host":"", "port":993, "username":"", "password":"", "use_ssl":True, "folders":[]}

@router.get("/imap")
def read_imap(current=Depends(get_current_user)):
    return _get("imap", DEFAULT_IMAP)

@router.put("/imap")
def write_imap(payload: Dict[str,Any] = Body(...), current=Depends(get_current_user)):
    cur = _get("imap", DEFAULT_IMAP)
    cur.update({k: payload.get(k, cur.get(k)) for k in DEFAULT_IMAP.keys()})
    _set("imap", cur)
    return cur

@router.post("/imap/test")
def test_imap(payload: Dict[str,Any] = Body(None), current=Depends(get_current_user)):
    cfg = _get("imap", DEFAULT_IMAP)
    if payload: cfg.update({k: payload.get(k, cfg.get(k)) for k in DEFAULT_IMAP.keys()})
    host, port, user, pwd, use_ssl = cfg["host"], int(cfg["port"]), cfg["username"], cfg["password"], bool(cfg["use_ssl"])
    if not host or not user:
        raise HTTPException(400, "Host and Username are required")
    try:
        if use_ssl: M = imaplib.IMAP4_SSL(host, port)
        else:
            M = imaplib.IMAP4(host, port)
            M.starttls(ssl_context=ssl.create_default_context())
        typ, _ = M.login(user, pwd)
        if typ != "OK": raise HTTPException(401, "Login failed")
        typ, boxes = M.list()
        M.logout()
        folders = []
        if typ == "OK" and boxes:
            for line in boxes:
                name = line.decode(errors="ignore").split(' "/" ',1)[-1].strip().strip('"')
                if name: folders.append(name)
        return {"ok": True, "folders": folders[:100]}
    except imaplib.IMAP4.error as e:
        raise HTTPException(401, f"IMAP error: {e}")
    except Exception as e:
        raise HTTPException(500, f"IMAP connect failed: {e}")
